from pydantic import BaseModel, Field
from typing import List, Optional, Literal
from datetime import datetime


class PantryItem(BaseModel):
    id: str
    name: str
    category: Literal['vegetables', 'meats', 'sauces', 'staples']
    freshness: int
    image_url: str
    status: Literal['use-soon', 'essential', 'seasonal']
    tag: Optional[str] = None


class IngredientMastered(BaseModel):
    name: str
    image_url: str
    mastered: bool


class Milestones(BaseModel):
    consistency_score: int
    new_flavors: int
    inflammation_risk: Literal['低', '中', '高']
    cooking_complexity: Literal['新手', '入门', '进阶', '专家']


class TasteDNA(BaseModel):
    savory: int
    acidic: int
    sweet: int


class UserProfile(BaseModel):
    level: int
    total_growth: int
    taste_dna: TasteDNA
    ingredients_mastered: List[IngredientMastered]
    milestones: Milestones


class HistoryItem(BaseModel):
    id: str
    recipe_title: str
    date: datetime
    action: str
    details: Optional[str] = None


class RecipeIngredient(BaseModel):
    name: str
    amount: str


class RecipeStep(BaseModel):
    step: int
    title: str
    instruction: str
    image_url: Optional[str] = None


class Recipe(BaseModel):
    id: str
    title: str
    match_percent: int = Field(ge=0, le=100)
    tags: List[str]
    calories: int
    macros: dict = Field(..., schema_extra={'example': {'protein': 18, 'carb': 45, 'fat': 22}})
    description: str
    why_recommend: str
    ingredients: List[RecipeIngredient]
    steps: List[RecipeStep]
    timing: str
    difficulty: Literal['简单', '中等', '困难']
    image_url: Optional[str] = None


class GenerateRecipeRequest(BaseModel):
    preference: Optional[str] = None
    selected_ingredients: Optional[List[str]] = None
    previous_recipe_title: Optional[str] = None
    evolve_prompt: Optional[str] = None


class ScanRequest(BaseModel):
    image_base64: Optional[str] = None


class AddIngredientRequest(BaseModel):
    name: str
    category: Optional[Literal['vegetables', 'meats', 'sauces', 'staples']] = 'vegetables'
    freshness: Optional[int] = 90
    status: Optional[Literal['use-soon', 'essential', 'seasonal']] = 'essential'


class EvolveProfileRequest(BaseModel):
    recipe_title: Optional[str] = None
    ingredients: Optional[List[str]] = None