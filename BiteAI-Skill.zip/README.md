# BiteAI 智能餐谋 - 纯后端 Skill 插件

## 项目简介

BiteAI（智能餐谋）是一款专业的治愈系 AI 烹饪助手 Skill 插件，为 Dify/Coze 等 AI 应用平台提供结构化 JSON 菜谱生成能力。

## 核心卖点

✨ **冰箱剩菜大变身**：根据冰箱现有食材精准匹配菜谱，最大化利用资源  
✨ **治愈系文案**：带情绪感知的暖心推荐话术，告别冰冷指令  
✨ **结构化输出**：标准 JSON 格式，方便前后端集成  
✨ **营养分析**：卡路里、蛋白质/碳水/脂肪比例一目了然  
✨ **场景适配**：支持老人、儿童、健身、减脂等个性化场景

---

## 接口参数说明

### /api/generate-recipe (POST)

生成治愈系菜谱的核心接口。

#### 入参 (Request Body)

| 参数名 | 类型 | 必填 | 说明 | 示例 |
|--------|------|------|------|------|
| `preference` | string | 否 | 用户偏好描述 | "我今天很累，想吃点暖的" |
| `selected_ingredients` | string[] | 否 | 已选中的食材列表 | ["鸡蛋", "番茄", "菠菜"] |
| `previous_recipe_title` | string | 否 | 前一次的菜谱名称（用于进化） | "番茄炒鸡蛋" |
| `evolve_prompt` | string | 否 | 进化需求描述 | "少点辣，多加点蔬菜" |

#### 出参 (Response Body, JSON Schema)

```json
{
  "id": "rec-1234567890",
  "title": "田园能量碗",
  "matchPercent": 93,
  "tags": ["高蛋白质", "低升糖", "20分钟"],
  "calories": 420,
  "macros": { "protein": 18, "carb": 45, "fat": 22 },
  "description": "一道富含植物蛋白和抗氧化成分的营养午餐",
  "whyRecommend": "这款能量碗采用了优质的鹰嘴豆作为蛋白质来源，能有效提升身体活力",
  "ingredients": [
    { "name": "有机鹰嘴豆", "amount": "400g" }
  ],
  "steps": [
    {
      "step": 1,
      "title": "准备基底食材",
      "instruction": "将羽衣甘蓝洗净撕碎，加入少量橄榄油和盐轻轻按摩",
      "image_url": "https://..."
    }
  ],
  "timing": "20分钟",
  "difficulty": "简单",
  "image_url": "https://..."
}
```

---

## 对接指南

### 在 Dify 中接入

1. **创建自定义插件**
   - 进入 Dify → 工作室 → 创建应用 → 添加自定义插件
   - 选择「OpenAPI/Swagger」模式
   - 上传 `openapi.json` 文件

2. **配置认证**
   - 插件类型选择「API Key」
   - 填写你的 DeepSeek API Key

3. **测试工具**
   - 输入测试参数 `preference` 和 `selected_ingredients`
   - 验证返回的 JSON 结构

### 在 Coze 中接入

1. **创建插件**
   - 进入 Coze Bot Studio → 插件管理 → 新建插件
   - 导入 `openapi.json` 或手动配置接口

2. **绑定工具**
   - 将 `generate-recipe` 工具绑定到你的 Bot 中
   - 设置触发条件为「用户询问吃什么」

---

## 本地部署

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 配置 API Key
cp .env.example .env
# 编辑 .env 填入 DEEPSEEK_API_KEY

# 3. 启动服务
uvicorn main:app --reload
# 或
python main.py
```

访问 `http://localhost:8000/docs` 查看交互式 API 文档。

---

## 项目结构

```
biteai-backend/
├── main.py          # FastAPI 主程序
├── schemas.py       # Pydantic 数据模型
├── requirements.txt # Python 依赖
├── .env.example     # 环境变量示例
├── README.md        # 本文档
└── openapi.json     # OpenAPI 规范（供大模型阅读）
```
