from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ValidationError
from typing import List, Optional, Any, Literal
import os
import json
import random
from datetime import datetime
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

app = FastAPI(title="BiteAI - 治愈系菜谱助手", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

client = OpenAI(
    api_key=os.getenv("DEEPSEEK_API_KEY"),
    base_url="https://api.deepseek.com/v1"
)

# ----------------------------------------------------
# Mock Database
# ----------------------------------------------------

class PantryItem:
    def __init__(self, id: str, name: str, category: str, freshness: int, image_url: str, status: str, tag: Optional[str] = None):
        self.id = id
        self.name = name
        self.category = category
        self.freshness = freshness
        self.image_url = image_url
        self.status = status
        self.tag = tag

pantry_ingredients: List[PantryItem] = [
    PantryItem(
        id="ing-1",
        name="嫩菠菜",
        category="vegetables",
        freshness=20,
        image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuBRY02KQsJqx8ZgdXSZs9R71pSLRoF0JpLfDj9VTKZX04a7OhzycHPldbVltJXSJMwy9bXJQ2qNtlvoZoB3zxCm_6BwbH---e5kT7s3lThA9QBZdq0Oeg7DEn_GoLCpzn88u6u7mM-lWDZ8BEucxHkBBYxdb2pCoGty6OtSYboKuRPiOfgWRgmXI-7C3DYOr-CKaQDOxMicb1L2Hs03fsXTgoBI-2MaxhW7GseYYzxdtIq0NvOUG5LLxIhnBahmmtQdnB0eMDSSeQ",
        status="use-soon"
    ),
    PantryItem(
        id="ing-2",
        name="熟牛油果",
        category="vegetables",
        freshness=35,
        image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuBpGiIwHvLTGpy0Czua-Tdu3MguL0w8mgRS4cCC8qm2EEFpe8Gr2ARMct5-m7_Eu0-450Y39GfUfmxYQ4OIaLGhNgBlc0yV-tHwTnYdSv-3h27Fj8SzHbtsm15bKqHu8v2D7KtLvnwAI8t-HkhZh0Csrkh3mNDMHDZ3dYZ3FWis17I9qic7DWHKBhMFzKSpWG7S3dq2wr60F3Pm-L-wClY4xv6XCMwkyRb3uWIfZL8mYtY3mstdUScYUq1g8Y1JJu7zlXQE5tm3Xg",
        status="use-soon"
    ),
    PantryItem(
        id="ing-3",
        name="全脂牛奶",
        category="meats",
        freshness=15,
        image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuCifSBCdN1JRJEUZFEezgLdsdhIcPqOd3BXAjVfNnECCz26wqGXSfWoSSofovDTDuUt-piqIIuu2qachDtjX27hsBqVutR3h0mTeq_o-qMvEFJPhzK6ZSGgV_rFZens32GVJJzYf46pj1FUxDKAyLsoAZjzFqtRGGJT-eYGnEXkVQwJPVTgv72Eya21tigRWyPxvsR2bsjGxHfk344vQMSUKPHcuHUFkapXhOEhru_LyPc3RCMF9bs_O3tku3Gz3AQ_ZPenHxNvCQ",
        status="use-soon"
    ),
    PantryItem(
        id="ing-4",
        name="草莓",
        category="vegetables",
        freshness=40,
        image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuBTXr2L9mvOLCURdkfXS0LAbnyYoXnhXzwuOBLcTFvHCZEfTeFEcG1K38eMr-FKFgBYq9gxYbCB0LtoMimx-G8dkupusfb-H30fnup6CTNP8wR2_4iftBUmdX0vcuM5HDtgD6rfGr4oik63mUewG7FmtEkkWgG55C3DFI_UT1ue1PPoK99QvIGpPzroOLhxunfjg0fIWGorsZiLqyKMh-Y1Sr2RLobRATS5Yp4c3MUepqmO92EU1CUG9OFO58bdnXef04BlO69vAg",
        status="use-soon"
    ),
    PantryItem(
        id="ing-5",
        name="希腊酸奶",
        category="meats",
        freshness=80,
        image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuDFkb7bu2GNGivrinQd0gB2UWFq_fNEbdFUEeRkrnfWbGqMMmF2Jj51zZaV0js6kKkkv0XjKe7eGHrXAx9IgqTpBiR4WP8dlqomfzzc_gSS3tbIXmaKA0vk2-VNMUCO2Gki8XKVYXyONQY2sRrGs5AFndCAgdNN-p-F1hMR8GW0tGqB5Z_aFaP4e9-ZDVZ49VQuviscFvu_ZjviSxjEgx-mEIpaRYViuZHhZ47GjUaxt6O0j_0XZwZ-LhE9d6S8bhnMV658kyR7AA",
        status="essential"
    ),
    PantryItem(
        id="ing-6",
        name="大号鸡蛋",
        category="meats",
        freshness=95,
        image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuBvRM-RZh3CUXjQRsbGcDbPrtQLmoXhIdCH4vnJR4QduBVdwYIqEhpWX2kn-p50gXjRaXjUG6Y0JXth8jOBINLX07YFhU4M-CpROjz_q-Vvlbq48Zb4EUBkTv3lRyONIUlpDIxIp6xixMzfx4IMc2y2BtXd5lBl_zdbsvuGZ24zFfAXvcy--kppw0_NjKtfyycGmHpfxpO74pNDo7pI3_lIyv8usp3tO2byzHvBTt69c7-IGhOX0dAYlfBY5KxhoxLT_pp0Wynq5A",
        status="essential"
    ),
    PantryItem(
        id="ing-7",
        name="酸种面包",
        category="staples",
        freshness=45,
        image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuCMFdYPsEzBK2KEhcyQxp0bbmgQaaHaj5JA95_PkxKaosYffbzCU2SqnNMj9FLEGSFKENJf3bDLQpS6ZC_V1d-A6uBLwdfB0Lz3GU6qkjoXMS4Y0IqewtKTbTmra4qLVJb1sNbn83EErk7yCyXcDIO67KlNiDoTPEAd79kXQ1q-ULyCHl_yRojXQSYKxMWyyNf1BZgZoUHb_rmJsbT5blm5BAWe6mEeIqWYeQ7Htl90MxO1P1QRJ6ODhWBPYJp8b0ExRcJCs6oPBQ",
        status="essential"
    ),
    PantryItem(
        id="ing-8",
        name="紫芦笋",
        category="vegetables",
        freshness=85,
        image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuDJOFqVrkOj9H8adTppLspjfGE9XR-CYaFpXrviB9-mgvJTbg-JKb8OffDMlWb-Sjo2nFRqmWVIk-Bhfaa3dKvugutCQjZKAzDeHgaT2lRg86AFf8Mwv6ApFKKhsvwofffomqNkWLksVBIkUxlI9gBCxSSU0ZTrGGymWXnZsZL5nGO_iBlQ5bYbpg-f037TVMRgWIkHLXzg7XrJs50HSblTm8kJSPyUIsnVurk4qMFfXN_dPOoK3cFC6Ydx4XTSpvevJvJvxLWXNg",
        status="seasonal",
        tag="春季首选"
    ),
    PantryItem(
        id="ing-9",
        name="新鲜大黄",
        category="vegetables",
        freshness=90,
        image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuDZ_digmZw_TajE5rCd7JoTEDTGwnCFDvf76UgSSes-p6vyxdzVoQUcGA04VUaydvdeVv0CkDDvGLhKJiXePelqhBKOEIK_IOrqYwclbORP3go08OPD17FIVvqib27yo4PzoqS3jDU0Vm9rS0wo2OhvS4qpc84RrNT30lTUnPiidHUCKIXCkySoZtNBhtV8HM2PAyVqJZ0kf2qx-WmX-eD9SWtK9MNDpoEu7jqYZs7JJlLFsp5gf93ymPwAFG8FFuyLrefhfbo3rw",
        status="seasonal",
        tag="新品到库"
    ),
]

user_profile = {
    "level": 12,
    "total_growth": 68,
    "taste_dna": {
        "savory": 88,
        "acidic": 42,
        "sweet": 15,
    },
    "ingredients_mastered": [
        {
            "name": "羽衣甘蓝",
            "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuAmzkt50Xj1yQCzNyd3p2eOtgQYhfKM_i9gV_611P8raJ40-B8-U1clhiRPjr4NmuESu5Uoq6d2-b3tz0kM-rPZ1dEG63ceRqFSh1CXw89unDJJjJJCZInZXkXP-HFDKgk10yYgeo4vMv7ofqKwr-e_vdE4zf5uWo6ykYTQ-Xwcc1nPVZAb9bwY9caW9vXK_HIGr5fMEGY1ZxJaeAbwiq8JbmMXZSiiOzf4zzGP3KRKi3XERrALOTSrFJ49csb77pyAdzqyDYybPA",
            "mastered": True,
        },
        {
            "name": "紫皮大蒜",
            "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuD8IDezW7yw13znCiUysyYD9D68SeitNX54Zy1Uiy91nUnBvpPmXwvH-IFhutPp45g18asKfFCt8oWoaPUlipCRwiHawAVcyTXZ9dXd2scoHVfb5wlYkHwXqwGA0fSXKTu70-oM2GsBYwYnEQBurCzUqyB-_C6Ft4eUpdClu60-ndYPeAz1NNDl73G6nuy6jtv1oZpBNTxqMhkr_9_ZShFD7FlMTM1C1eHA70wE3_C51bquz40pQajr6EI0hOi-DOxw7yV7SiPJqg",
            "mastered": True,
        },
        {
            "name": "野姜",
            "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuDrSJ7t3Yz-fOTYm_wz3HYjOiquj0p5C4vsrLe2CnDySYubArbRH_Knb7124R5ysi6u3TyC9yIOp9FLDyXGjYG3e2zEA1nyVUqI78zUa9mn6AsC6GOwv5vuzFbF1Glocpp34IFZKKSpnJ3X68X0O9eKUqb0kps-zYsEBzwNvOAqPy97X6Q8-Zf-9JVhOgW2ZvAvYNYNKFcHaLoavuXMd-I3LUNL8r7UNA7LVlUs7s3wBWNudg1r3x3f4NPFcv13mPJYPJxXLhdztA",
            "mastered": False,
        },
        {
            "name": "姜黄",
            "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuCGGRYMKKQoqaDi9CEU4AgZyZ8JqnPoPCt18XGc7hGjqmskwmHdGMI6LtqYul3Lop3Z-Jm3CQfRswRN6dROGU_SomvEAxkeTJXHgh3gZK3N9F4AjF7anh2IyRht75arDQTJ69wlnA53H3_-yrC2ASMZ9uVwHVKPJn1LWAJEOVnw-lvxF5cekAs1SBBhu9RIjyn6qgfAjaF1Z8Tw02SP12xhh9j4gB7epKLJ9l4b0mCX_gvsPUFq3gqm0JuAN0BTRtY4yeVmaedM9A",
            "mastered": False,
        },
    ],
    "milestones": {
        "consistency_score": 92,
        "new_flavors": 14,
        "inflammation_risk": "低",
        "cooking_complexity": "专家",
    },
}

user_history = [
    {
        "id": "hist-1",
        "recipe_title": "经典西红柿炒鸡蛋",
        "date": "2026-05-24T18:30:00Z",
        "action": "confirmed",
    },
    {
        "id": "hist-2",
        "recipe_title": "意式番茄罗勒沙拉",
        "date": "2026-05-25T12:00:00Z",
        "action": "confirmed",
    },
]

default_recipes = [
    {
        "id": "rec-1",
        "title": "地中海能量碗",
        "match_percent": 98,
        "tags": ["高纤维", "纯素", "20分钟"],
        "calories": 420,
        "macros": {"protein": 18, "carb": 45, "fat": 22},
        "description": "一道富含植物蛋白和抗氧化成分的营养午餐，口感丰富，色彩斑斓。",
        "why_recommend": "这款能量碗采用了优质的鹰嘴豆作为蛋白质来源，配合牛油果提供的心血管健康脂肪。大量的深色叶菜富含维生素K和叶酸，能有效提升身体活力。",
        "ingredients": [
            {"name": "有机鹰嘴豆", "amount": "400g"},
            {"name": "成熟牛油果", "amount": "1 个"},
            {"name": "樱桃番茄", "amount": "150g"},
            {"name": "羽衣甘蓝", "amount": "100g"},
            {"name": "特级初榨橄榄油", "amount": "2 勺"}
        ],
        "steps": [
            {
                "step": 1,
                "title": "准备基底食材",
                "instruction": "将羽衣甘蓝洗净撕碎，加入少量橄榄油和盐轻轻按摩，使其质地变软。樱桃番茄对半切开备用。",
                "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuCh0Q8O1U-6f3fe-5fikXABom4ZthfwanG53qlzGHk9cpbz0qxtu3el7__XaIuWWDA3tiNtYalT9YvErO0M4zCCNqS_3vE_DJJGmtfs86OTMRiIl9QgUnnaz40vDve6O6EycwbFKHg1vJRAyo5WNCpuUSjVLTr1Lo-ujPbVRHoOrp1AcegGazuvQ1R9NtjNqq-_eKAgaGaKUBIs-qsXKlOUOv9fAA-m5R_Vy0Y3PKepcOKdA0tGPBWJz-m9VY630ZyzA5murkFecg"
            },
            {
                "step": 2,
                "title": "烘烤或加热鹰嘴豆",
                "instruction": "鹰嘴豆沥干水，拌入红椒粉和黑胡椒。在平底锅中用中火炒至微焦，或放入烤箱180度烤15分钟至酥脆。",
                "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuDh3Kw581hrX96DDw1n_k6FGiReK5StTfosglmt_Ga43sAk-ZRfn-W2I6HgVc46CW7ohsM8Fr7olX_RCkU7tI_veARt9l6p461s2PZ16Ot40HLtQSZOcnFB8yVexU6gRV501xh7Z-yxDFAhDXftNSeY6ig3fsNUjZLVKC17YccTFPhlLYGGgyE8FnIC-NcXZ411YUEQdGE0VZ73eFJz0oe5_Wuo_hBn4YMWnSdxvaPQm8I5pbvHhOJZMI2T1OzJvr4Gf7DSqdOISg"
            },
            {
                "step": 3,
                "title": "组装与摆盘",
                "instruction": "将甘蓝铺在碗底，依次放上鹰嘴豆、番茄和牛油果块。淋上柠檬汁和自制的芝麻酱。",
                "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuDtsqEp4wwX9bFQEheRoEQ20Djc4j7Ci8TrhPQJa3d4cIuyCn6ycZ6eZ1_-Vq0a4ge9DH6x2_ubzGzsTD5_geqCzVxtGuko6unRNnHyv9txdtXhfkfMLUUu06FucAOYDPDsjcCp4B2adi1r8KIIdqrY0wjY110prm5OTAM0XLg6eulMMkDtyA27oTXDSEbz1IlDGlz80X3PHNOdUQNMC2umBP7HDN9nAqoE2voIKVFRw_fsml6nYZG6t79WkMtRwIzxvq2W1zkkkw"
            }
        ],
        "timing": "20分钟",
        "difficulty": "简单",
        "category": "运动健身"
    },
    {
        "id": "rec-2",
        "title": "生姜味增暖身汤",
        "match_percent": 95,
        "tags": ["极速美味", "养胃", "12分钟"],
        "calories": 240,
        "macros": {"protein": 12, "carb": 28, "fat": 8},
        "description": "为疲惫的心灵提供即时慰藉，利用生姜辛温驱寒与味增鲜美味道，暖身补气。",
        "why_recommend": "生姜富含姜辣素，可迅速扩张血管促进血液循环；味增提供多重氨基酸与益生菌，减轻胃肠负担，对高度疲劳及受寒人群非常有益。",
        "ingredients": [
            {"name": "有机豆腐条", "amount": "150g"},
            {"name": "生姜片", "amount": "15g"},
            {"name": "味增酱", "amount": "1.5 匙"},
            {"name": "鲜海带芽", "amount": "30g"},
            {"name": "香葱花", "amount": "5g"}
        ],
        "steps": [
            {
                "step": 1,
                "title": "处理生姜和豆腐",
                "instruction": "生姜去皮切成薄片或细丝。豆腐轻轻印干水分，切为1.5厘米方块。泡发海带芽。",
                "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuCh0Q8O1U-6f3fe-5fikXABom4ZthfwanG53qlzGHk9cpbz0qxtu3el7__XaIuWWDA3tiNtYalT9YvErO0M4zCCNqS_3vE_DJJGmtfs86OTMRiIl9QgUnnaz40vDve6O6EycwbFKHg1vJRAyo5WNCpuUSjVLTr1Lo-ujPbVRHoOrp1AcegGazuvQ1R9NtjNqq-_eKAgaGaKUBIs-qsXKlOUOv9fAA-m5R_Vy0Y3PKepcOKdA0tGPBWJz-m9VY630ZyzA5murkFecg"
            },
            {
                "step": 2,
                "title": "温煮汤底",
                "instruction": "锅中注入500ml水，放入姜丝与海带芽大火烧开，再转中小火慢煮5分钟，让姜辣素充分融入汤底。倒入豆腐块煮2分钟。",
                "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuDh3Kw581hrX96DDw1n_k6FGiReK5StTfosglmt_Ga43sAk-ZRfn-W2I6HgVc46CW7ohsM8Fr7olX_RCkU7tI_veARt9l6p461s2PZ16Ot40HLtQSZOcnFB8yVexU6gRV501xh7Z-yxDFAhDXftNSeY6ig3fsNUjZLVKC17YccTFPhlLYGGgyE8FnIC-NcXZ411YUEQdGE0VZ73eFJz0oe5_Wuo_hBn4YMWnSdxvaPQm8I5pbvHhOJZMI2T1OzJvr4Gf7DSqdOISg"
            },
            {
                "step": 3,
                "title": "拌融味增及点缀",
                "instruction": "关火。用汤勺取少量温汤，将味增酱充分化开后倒入锅内，轻轻推匀（不可在沸腾时下味增，以免破坏风味）。起锅装碗，撒上香葱花即可。",
                "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuNgW1qp5ibfDgTt3eJ-BHbwUNy11MmDaV8B_nLL_uiBm6vsobFYXUGphHBPIKT4YmjZa2sfRZkcaSVGUdfGgRositkV936MV2gIeO0A55VBi43468Q_jluLTQseWjW9xhPulC2sDshu0t8lVTXk-s7hhf64nBPBliBczNTprw99li6iMA7jZ5Dr88qcsPAk-gZWKxDLH35331JCVhPSg1-kFhLwmOFleGflafF412XjrjZ1aZqlQCsNPXlLOpHzqLUpdOUHYHPUA"
            }
        ],
        "timing": "12分钟",
        "difficulty": "简单",
        "category": "老年人"
    },
    {
        "id": "rec-3",
        "title": "黑松露丝滑野菇烩饭",
        "match_percent": 90,
        "tags": ["大厨推荐", "浓郁暖身", "25分钟"],
        "calories": 550,
        "macros": {"protein": 14, "carb": 68, "fat": 18},
        "description": "全新的风味深度，黑松露油与混合野菇的奢华融合，带来浓香四溢、口感糯滑的盛宴。",
        "why_recommend": "松露富含多种活性多糖与氨基酸，混合菇类提供丰富的谷氨酸，协同产生极致的鲜美。丰富的优质油脂与慢消化碳水，可为寒冬夜间持续源源不断地输送能量。",
        "ingredients": [
            {"name": "高质烩饭米 (Arborio)", "amount": "100g"},
            {"name": "混合鲜野菇", "amount": "120g"},
            {"name": "黑松露酱/松露油", "amount": "1.5 勺"},
            {"name": "帕玛森干酪末", "amount": "20g"},
            {"name": "无盐黄油", "amount": "15g"},
            {"name": "暖鲜蔬菜汤/鸡汤", "amount": "400ml"}
        ],
        "steps": [
            {
                "step": 1,
                "title": "炒香鲜菇与烩饭米",
                "instruction": "鲜菇切薄片，用干锅大火力煸炒干多余水分并微黄盛出。同锅放植物油小火将高汤温热。炒锅中加入黄油，投入烩饭米煸炒至米粒边缘半透明透明半金黄。",
                "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuCh0Q8O1U-6f3fe-5fikXABom4ZthfwanG53qlzGHk9cpbz0qxtu3el7__XaIuWWDA3tiNtYalT9YvErO0M4zCCNqS_3vE_DJJGmtfs86OTMRiIl9QgUnnaz40vDve6O6EycwbFKHg1vJRAyo5WNCpuUSjVLTr1Lo-ujPbVRHoOrp1AcegGazuvQ1R9NtjNqq-_eKAgaGaKUBIs-qsXKlOUOv9fAA-m5R_Vy0Y3PKepcOKdA0tGPBWJz-m9VY630ZyzA5murkFecg"
            },
            {
                "step": 2,
                "title": "分次注入热汤烹煮",
                "instruction": "分次舀入一勺勺温热高汤，保持中小火不断搅动，使米粒释放淀粉。待高汤吸干后再加入下一勺。此步骤约持续15分钟，直至烩饭米达到外糯内韧状态。中途注入先前炒好的野菇。",
                "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuDh3Kw581hrX96DDw1n_k6FGiReK5StTfosglmt_Ga43sAk-ZRfn-W2I6HgVc46CW7ohsM8Fr7olX_RCkU7tI_veARt9l6p461s2PZ16Ot40HLtQSZOcnFB8yVexU6gRV501xh7Z-yxDFAhDXftNSeY6ig3fsNUjZLVKC17YccTFPhlLYGGgyE8FnIC-NcXZ411YUEQdGE0VZ73eFJz0oe5_Wuo_hBn4YMWnSdxvaPQm8I5pbvHhOJZMI2T1OzJvr4Gf7DSqdOISg"
            },
            {
                "step": 3,
                "title": "乳化(Mantecatura)及黑松露点缀",
                "instruction": "关火移开热源。趁着余温，迅速加入Parmesan乳酪粉与松露酱，激烈搅动半分钟，使其乳化形成奶油般丝滑的酱汁。盛入圆盘中，可利用微绿苗或黑松露片点缀装扮。",
                "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuAStsL5N6gbBXtmYOtVNCkAkGEXBfdTzrGOV47_4cY8VyhIBJjhLGI8wI6JwgHCf4VJEFXVvPA-KRqHZh28Tg0cSIF8f6MDBCFJr6P4JiBMRTBELfvusafoD7SciqyvyTpHXRh78slGIOsUTetUZ16VlcwQ50kcMt_66MHQiMVqR4YqD0q7x6b9Yk9cpfok_-il4jR6hlvA-7KqN243WNxEPr5Klv1vTOY-taXulzssquFVRA9aK4TQu_jdVaXVQcxCGVwexqH2zw"
            }
        ],
        "timing": "25分钟",
        "difficulty": "中等",
        "category": "儿童群体"
    }
]

# ----------------------------------------------------
# Helper Functions
# ----------------------------------------------------

def get_aesthetic_recipe_images(title: str, tags: List[str]) -> dict:
    title_lower = title.lower()
    
    main_url = "https://lh3.googleusercontent.com/aida-public/AB6AXuDCJ6PrI7pS-m7ms_whMqirqQmVwM60_P0HDT2Kl7yyiXwjegP6Go8fXCpJfkvE4VmCR-C9TVMjQGg1G1qHHueVpp0cwpFZ7XfZ4Vcgm_MKb_EA1ZUI_77vZa2xdUf2RpzRy0c1UWPn8F7Vv_jam1ackAtcW_sHYEcaEUlhqcHB56ecY2sdddhiCpgcZM1J_ZZWAdAdPpgKguMaZTOTskeTNHKbK0eSSpqH1ZTGk_4GH1D_Rdb4NAYimiwSOTY8Bj-drVbWN9I55g"
    step1_url = "https://lh3.googleusercontent.com/aida-public/AB6AXuCh0Q8O1U-6f3fe-5fikXABom4ZthfwanG53qlzGHk9cpbz0qxtu3el7__XaIuWWDA3tiNtYalT9YvErO0M4zCCNqS_3vE_DJJGmtfs86OTMRiIl9QgUnnaz40vDve6O6EycwbFKHg1vJRAyo5WNCpuUSjVLTr1Lo-ujPbVRHoOrp1AcegGazuvQ1R9NtjNqq-_eKAgaGaKUBIs-qsXKlOUOv9fAA-m5R_Vy0Y3PKepcOKdA0tGPBWJz-m9VY630ZyzA5murkFecg"
    step2_url = "https://lh3.googleusercontent.com/aida-public/AB6AXuDh3Kw581hrX96DDw1n_k6FGiReK5StTfosglmt_Ga43sAk-ZRfn-W2I6HgVc46CW7ohsM8Fr7olX_RCkU7tI_veARt9l6p461s2PZ16Ot40HLtQSZOcnFB8yVexU6gRV501xh7Z-yxDFAhDXftNSeY6ig3fsNUjZLVKC17YccTFPhlLYGGgyE8FnIC-NcXZ411YUEQdGE0VZ73eFJz0oe5_Wuo_hBn4YMWnSdxvaPQm8I5pbvHhOJZMI2T1OzJvr4Gf7DSqdOISg"
    step3_url = "https://lh3.googleusercontent.com/aida-public/AB6AXuDtsqEp4wwX9bFQEheRoEQ20Djc4j7Ci8TrhPQJa3d4cIuyCn6ycZ6eZ1_-Vq0a4ge9DH6x2_ubzGzsTD5_geqCzVxtGuko6unRNnHyv9txdtXhfkfMLUUu06FucAOYDPDsjcCp4B2adi1r8KIIdqrY0wjY110prm5OTAM0XLg6eulMMkDtyA27oTXDSEbz1IlDGlz80X3PHNOdUQNMC2umBP7HDN9nAqoE2voIKVFRw_fsml6nYZG6t79WkMtRwIzxvq2W1zkkkw"

    keyword_map = {
        "味噌汤": "https://lh3.googleusercontent.com/aida-public/AB6AXuNgW1qp5ibfDgTt3eJ-BHbwUNy11MmDaV8B_nLL_uiBm6vsobFYXUGphHBPIKT4YmjZa2sfRZkcaSVGUdfGgRositkV936MV2gIeO0A55VBi43468Q_jluLTQseWjW9xhPulC2sDshu0t8lVTXk-s7hhf64nBPBliBczNTprw99li6iMA7jZ5Dr88qcsPAk-gZWKxDLH35331JCVhPSg1-kFhLwmOFleGflafF412XjrjZ1aZqlQCsNPXlLOpHzqLUpdOUHYHPUA",
        "miso": "https://lh3.googleusercontent.com/aida-public/AB6AXuNgW1qp5ibfDgTt3eJ-BHbwUNy11MmDaV8B_nLL_uiBm6vsobFYXUGphHBPIKT4YmjZa2sfRZkcaSVGUdfGgRositkV936MV2gIeO0A55VBi43468Q_jluLTQseWjW9xhPulC2sDshu0t8lVTXk-s7hhf64nBPBliBczNTprw99li6iMA7jZ5Dr88qcsPAk-gZWKxDLH35331JCVhPSg1-kFhLwmOFleGflafF412XjrjZ1aZqlQCsNPXlLOpHzqLUpdOUHYHPUA",
        "布丁": "https://lh3.googleusercontent.com/aida-public/AB6AXuCSt8Izr9sbR3v9VFyVVCT7hrQNkUtFfL4jxDNdRlUTHdvQs4b0Q5ddlGogDrfzmB2VqqgQCFD1rAXr5NzlySN3j5UZ5uM20CJKbrqbRQLkVu9bVL0-8D2iJond3Ea0n0sgM3NM3wgWPorJMS7yOrQlNvDX8fGefuScLGjOXbA_JxBC45yDwMzyoyjofV_MTBR1nnz1hhOMzt9NWjDrFAquGvpZfr7nplC691YaNUp-fEkMii-JL-FwDDLYoqKW0lpZs1PZ1CbRcg",
        "三文鱼": "https://lh3.googleusercontent.com/aida-public/AB6AXuCSt8Izr9sbR3v9VFyVVCT7hrQNkUtFfL4jxDNdRlUTHdvQs4b0Q5ddlGogDrfzmB2VqqgQCFD1rAXr5NzlySN3j5UZ5uM20CJKbrqbRQLkVu9bVL0-8D2iJond3Ea0n0sgM3NM3wgWPorJMS7yOrQlNvDX8fGefuScLGjOXbA_JxBC45yDwMzyoyjofV_MTBR1nnz1hhOMzt9NWjDrFAquGvpZfr7nplC691YaNUp-fEkMii-JL-FwDDLYoqKW0lpZs1PZ1CbRcg",
        "salmon": "https://lh3.googleusercontent.com/aida-public/AB6AXuCSt8Izr9sbR3v9VFyVVCT7hrQNkUtFfL4jxDNdRlUTHdvQs4b0Q5ddlGogDrfzmB2VqqgQCFD1rAXr5NzlySN3j5UZ5uM20CJKbrqbRQLkVu9bVL0-8D2iJond3Ea0n0sgM3NM3wgWPorJMS7yOrQlNvDX8fGefuScLGjOXbA_JxBC45yDwMzyoyjofV_MTBR1nnz1hhOMzt9NWjDrFAquGvpZfr7nplC691YaNUp-fEkMii-JL-FwDDLYoqKW0lpZs1PZ1CbRcg",
        "烩饭": "https://lh3.googleusercontent.com/aida-public/AB6AXuAStsL5N6gbBXtmYOtVNCkAkGEXBfdTzrGOV47_4cY8VyhIBJjhLGI8wI6JwgHCf4VJEFXVvPA-KRqHZh28Tg0cSIF8f6MDBCFJr6P4JiBMRTBELfvusafoD7SciqyvyTpHXRh78slGIOsUTetUZ16VlcwQ50kcMt_66MHQiMVqR4YqD0q7x6b9Yk9cpfok_-il4jR6hlvA-7KqN243WNxEPr5Klv1vTOY-taXulzssquFVRA9aK4TQu_jdVaXVQcxCGVwexqH2zw",
        "risotto": "https://lh3.googleusercontent.com/aida-public/AB6AXuAStsL5N6gbBXtmYOtVNCkAkGEXBfdTzrGOV47_4cY8VyhIBJjhLGI8wI6JwgHCf4VJEFXVvPA-KRqHZh28Tg0cSIF8f6MDBCFJr6P4JiBMRTBELfvusafoD7SciqyvyTpHXRh78slGIOsUTetUZ16VlcwQ50kcMt_66MHQiMVqR4YqD0q7x6b9Yk9cpfok_-il4jR6hlvA-7KqN243WNxEPr5Klv1vTOY-taXulzssquFVRA9aK4TQu_jdVaXVQcxCGVwexqH2zw",
        "沙拉": "https://lh3.googleusercontent.com/aida-public/AB6AXuAmaN68EAsi9IjXdOG4pmzZSiaS75O1rFh9jU4_OpXxRhDp6AN-y-0E-4A1o1Tv_sXKmtiG3FT04yDEYcHrZZ4xvgpCNoCv_3GKiiALE-d_gylSJE4Nrj72dvZNSneoybqFa2PYlxQ7IukWPMOFa-dNeeGWcwUkBlpbUT8eMtyM4stzr_X51p-m313_2zsqEtE_fEo1c9QNYjk7wDwUb9glCdqUvsV4aa-b6ZDUUhTJhfemcD9SzQjAuzi7nDHA7gNuhWkNhqetKg",
        "salad": "https://lh3.googleusercontent.com/aida-public/AB6AXuAmaN68EAsi9IjXdOG4pmzZSiaS75O1rFh9jU4_OpXxRhDp6AN-y-0E-4A1o1Tv_sXKmtiG3FT04yDEYcHrZZ4xvgpCNoCv_3GKiiALE-d_gylSJE4Nrj72dvZNSneoybqFa2PYlxQ7IukWPMOFa-dNeeGWcwUkBlpbUT8eMtyM4stzr_X51p-m313_2zsqEtE_fEo1c9QNYjk7wDwUb9glCdqUvsV4aa-b6ZDUUhTJhfemcD9SzQjAuzi7nDHA7gNuhWkNhqetKg",
        "西红柿炒鸡蛋": "https://lh3.googleusercontent.com/aida-public/AB6AXuBvRM-RZh3CUXjQRsbGcDbPrtQLmoXhIdCH4vnJR4QduBVdwYIqEhpWX2kn-p50gXjRaXjUG6Y0JXth8jOBINLX07YFhU4M-CpROjz_q-Vvlbq48Zb4EUBkTv3lRyONIUlpDIxIp6xixMzfx4IMc2y2BtXd5lBl_zdbsvuGZ24zFfAXvcy--kppw0_NjKtfyycGmHpfxpO74pNDo7pI3_lIyv8usp3tO2byzHvBTt69c7-IGhOX0dAYlfBY5KxhoxLT_pp0Wynq5A",
        "西红柿炒蛋": "https://lh3.googleusercontent.com/aida-public/AB6AXuBvRM-RZh3CUXjQRsbGcDbPrtQLmoXhIdCH4vnJR4QduBVdwYIqEhpWX2kn-p50gXjRaXjUG6Y0JXth8jOBINLX07YFhU4M-CpROjz_q-Vvlbq48Zb4EUBkTv3lRyONIUlpDIxIp6xixMzfx4IMc2y2BtXd5lBl_zdbsvuGZ24zFfAXvcy--kppw0_NjKtfyycGmHpfxpO74pNDo7pI3_lIyv8usp3tO2byzHvBTt69c7-IGhOX0dAYlfBY5KxhoxLT_pp0Wynq5A",
        "西兰花": "https://lh3.googleusercontent.com/aida-public/AB6AXuAbv5NJTVXBfjBzsf25iikQP0tSfQYyMY2O9Bi3EZrW-tKEIXDmL3jmHpCDzsW1D2UFzBtsmk7yepb1kMWUWC25kAxuIPBuAaXRU1QK-V3P_5G-iP283SOxWKAkUSUL5sp828W0VRn5BpvnwN5phmGjLuXnw1a_juY04ughZV32CDzUa4ZRAn_2nKv583xMx3q4Ha0jtf_u8Uq42VQka4H7LLPmwO6ZnpngHFvA1X9wTEmwCNRtHDUdBM2CQwl90YL7WwJ95ZEmkA",
        "broccoli": "https://lh3.googleusercontent.com/aida-public/AB6AXuAbv5NJTVXBfjBzsf25iikQP0tSfQYyMY2O9Bi3EZrW-tKEIXDmL3jmHpCDzsW1D2UFzBtsmk7yepb1kMWUWC25kAxuIPBuAaXRU1QK-V3P_5G-iP283SOxWKAkUSUL5sp828W0VRn5BpvnwN5phmGjLuXnw1a_juY04ughZV32CDzUa4ZRAn_2nKv583xMx3q4Ha0jtf_u8Uq42VQka4H7LLPmwO6ZnpngHFvA1X9wTEmwCNRtHDUdBM2CQwl90YL7WwJ95ZEmkA",
        "波奇饭": "https://lh3.googleusercontent.com/aida-public/AB6AXuAMesMZwQL2e3_keHjdU4KwTJlm14aV9JO5d-sFIQhgtLj0rDFKrIZ1hM9er-nEkeLyLwqJDOFy9Pp8DID-P1taBGVruIyRu6FELjrbMZfHz7BeI_B2nGNzsorlkXM0uTP8gpM1YCMR-y0OXIZ7P5OG58iuG_Sr29OihQ9Oy_gG35RtGziHbQE_hD2SyzSyzdNWMl24FOh5-Z3e_jW9OByfEPnWlDCLCX8yOz_8idbguKxO4oqeqhYN8nYVmmnZspEfK9LMBpzeCg",
        "poke": "https://lh3.googleusercontent.com/aida-public/AB6AXuAMesMZwQL2e3_keHjdU4KwTJlm14aV9JO5d-sFIQhgtLj0rDFKrIZ1hM9er-nEkeLyLwqJDOFy9Pp8DID-P1taBGVruIyRu6FELjrbMZfHz7BeI_B2nGNzsorlkXM0uTP8gpM1YCMR-y0OXIZ7P5OG58iuG_Sr29OihQ9Oy_gG35RtGziHbQE_hD2SyzSyzdNWMl24FOh5-Z3e_jW9OByfEPnWlDCLCX8yOz_8idbguKxO4oqeqhYN8nYVmmnZspEfK9LMBpzeCg",
        "燕麦": "https://lh3.googleusercontent.com/aida-public/AB6AXuCMFdYPsEzBK2KEhcyQxp0bbmgQaaHaj5JA95_PkxKaosYffbzCU2SqnNMj9FLEGSFKENJf3bDLQpS6ZC_V1d-A6uBLwdfB0Lz3GU6qkjoXMS4Y0IqewtKTbTmra4qLVJb1sNbn83EErk7yCyXcDIO67KlNiDoTPEAd79kXQ1q-ULyCHl_yRojXQSYKxMWyyNf1BZgZoUHb_rmJsbT5blm5BAWe6mEeIqWYeQ7Htl90MxO1P1QRJ6ODhWBPYJp8b0ExRcJCs6oPBQ",
        "oatmeal": "https://lh3.googleusercontent.com/aida-public/AB6AXuCMFdYPsEzBK2KEhcyQxp0bbmgQaaHaj5JA95_PkxKaosYffbzCU2SqnNMj9FLEGSFKENJf3bDLQpS6ZC_V1d-A6uBLwdfB0Lz3GU6qkjoXMS4Y0IqewtKTbTmra4qLVJb1sNbn83EErk7yCyXcDIO67KlNiDoTPEAd79kXQ1q-ULyCHl_yRojXQSYKxMWyyNf1BZgZoUHb_rmJsbT5blm5BAWe6mEeIqWYeQ7Htl90MxO1P1QRJ6ODhWBPYJp8b0ExRcJCs6oPBQ",
        "思慕雪": "https://lh3.googleusercontent.com/aida-public/AB6AXuClJ5uXz5wrzr0ED7BKFC3dRLABZXXUsHbxDPqXK5HPODDpU77UIEa6J9IVLtjGcBSpa6j2tEyclGQ51v2Mkf5cJiPhyE_6Q7k_x_MSUgT_J3BvunHPl9X2s1Q_VGZ1jx-qAN_WxxZ97YfXP8wwocJKsVLVI2abKIv7TrDE6QFg-Sv-7BULZd7u4GrhMLrJCoY49fSsbWowCgBxAlSEiwtsplRiZPCDLUl82hIu6iuCjaGyYqID-QFOegxxm2BfVx81pU2loo0QYg"
    }

    for keyword, url in keyword_map.items():
        if keyword in title_lower:
            main_url = url
            break

    if "高蛋白" in tags or "三文鱼" in title_lower:
        step2_url = "https://lh3.googleusercontent.com/aida-public/AB6AXuDh3Kw581hrX96DDw1n_k6FGiReK5StTfosglmt_Ga43sAk-ZRfn-W2I6HgVc46CW7ohsM8Fr7olX_RCkU7tI_veARt9l6p461s2PZ16Ot40HLtQSZOcnFB8yVexU6gRV501xh7Z-yxDFAhDXftNSeY6ig3fsNUjZLVKC17YccTFPhlLYGGgyE8FnIC-NcXZ411YUEQdGE0VZ73eFJz0oe5_Wuo_hBn4YMWnSdxvaPQm8I5pbvHhOJZMI2T1OzJvr4Gf7DSqdOISg"

    return {"main_url": main_url, "step1_url": step1_url, "step2_url": step2_url, "step3_url": step3_url}

# ----------------------------------------------------
# API Routes
# ----------------------------------------------------

@app.get("/api/pantry", response_model=List[dict])
async def get_pantry():
    return [
        {
            "id": item.id,
            "name": item.name,
            "category": item.category,
            "freshness": item.freshness,
            "image_url": item.image_url,
            "status": item.status,
            "tag": item.tag
        }
        for item in pantry_ingredients
    ]

@app.post("/api/pantry", response_model=List[dict])
async def add_ingredient(request: dict):
    name = request.get("name")
    if not name:
        raise HTTPException(status_code=400, detail="Ingredient name is required")
    
    category = request.get("category", "vegetables")
    freshness = request.get("freshness", 90)
    status = request.get("status", "essential")
    
    new_item = PantryItem(
        id=f"ing-{datetime.now().timestamp()}",
        name=name,
        category=category,
        freshness=freshness,
        image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuDFkb7bu2GNGivrinQd0gB2UWFq_fNEbdFUEeRkrnfWbGqMMmF2Jj51zZaV0js6kKkkv0XjKe7eGHrXAx9IgqTpBiR4WP8dlqomfzzc_gSS3tbIXmaKA0vk2-VNMUCO2Gki8XKVYXyONQY2sRrGs5AFndCAgdNN-p-F1hMR8GW0tGqB5Z_aFaP4e9-ZDVZ49VQuviscFvu_ZjviSxjEgx-mEIpaRYViuZHhZ47GjUaxt6O0j_0XZwZ-LhE9d6S8bhnMV658kyR7AA",
        status=status
    )
    pantry_ingredients.insert(0, new_item)
    
    return await get_pantry()

@app.post("/api/pantry/reset", response_model=List[dict])
async def reset_pantry():
    global pantry_ingredients
    pantry_ingredients = [
        PantryItem(
            id="ing-1",
            name="嫩菠菜",
            category="vegetables",
            freshness=20,
            image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuBRY02KQsJqx8ZgdXSZs9R71pSLRoF0JpLfDj9VTKZX04a7OhzycHPldbVltJXSJMwy9bXJQ2qNtlvoZoB3zxCm_6BwbH---e5kT7s3lThA9QBZdq0Oeg7DEn_GoLCpzn88u6u7mM-lWDZ8BEucxHkBBYxdb2pCoGty6OtSYboKuRPiOfgWRgmXI-7C3DYOr-CKaQDOxMicb1L2Hs03fsXTgoBI-2MaxhW7GseYYzxdtIq0NvOUG5LLxIhnBahmmtQdnB0eMDSSeQ",
            status="use-soon"
        ),
        PantryItem(
            id="ing-2",
            name="熟牛油果",
            category="vegetables",
            freshness=35,
            image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuBpGiIwHvLTGpy0Czua-Tdu3MguL0w8mgRS4cCC8qm2EEFpe8Gr2ARMct5-m7_Eu0-450Y39GfUfmxYQ4OIaLGhNgBlc0yV-tHwTnYdSv-3h27Fj8SzHbtsm15bKqHu8v2D7KtLvnwAI8t-HkhZh0Csrkh3mNDMHDZ3dYZ3FWis17I9qic7DWHKBhMFzKSpWG7S3dq2wr60F3Pm-L-wClY4xv6XCMwkyRb3uWIfZL8mYtY3mstdUScYUq1g8Y1JJu7zlXQE5tm3Xg",
            status="use-soon"
        ),
        PantryItem(
            id="ing-3",
            name="全脂牛奶",
            category="meats",
            freshness=15,
            image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuCifSBCdN1JRJEUZFEezgLdsdhIcPqOd3BXAjVfNnECCz26wqGXSfWoSSofovDTDuUt-piqIIuu2qachDtjX27hsBqVutR3h0mTeq_o-qMvEFJPhzK6ZSGgV_rFZens32GVJJzYf46pj1FUxDKAyLsoAZjzFqtRGGJT-eYGnEXkVQwJPVTgv72Eya21tigRWyPxvsR2bsjGxHfk344vQMSUKPHcuHUFkapXhOEhru_LyPc3RCMF9bs_O3tku3Gz3AQ_ZPenHxNvCQ",
            status="use-soon"
        ),
        PantryItem(
            id="ing-4",
            name="草莓",
            category="vegetables",
            freshness=40,
            image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuBTXr2L9mvOLCURdkfXS0LAbnyYoXnhXzwuOBLcTFvHCZEfTeFEcG1K38eMr-FKFgBYq9gxYbCB0LtoMimx-G8dkupusfb-H30fnup6CTNP8wR2_4iftBUmdX0vcuM5HDtgD6rfGr4oik63mUewG7FmtEkkWgG55C3DFI_UT1ue1PPoK99QvIGpPzroOLhxunfjg0fIWGorsZiLqyKMh-Y1Sr2RLobRATS5Yp4c3MUepqmO92EU1CUG9OFO58bdnXef04BlO69vAg",
            status="use-soon"
        ),
        PantryItem(
            id="ing-5",
            name="希腊酸奶",
            category="meats",
            freshness=80,
            image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuDFkb7bu2GNGivrinQd0gB2UWFq_fNEbdFUEeRkrnfWbGqMMmF2Jj51zZaV0js6kKkkv0XjKe7eGHrXAx9IgqTpBiR4WP8dlqomfzzc_gSS3tbIXmaKA0vk2-VNMUCO2Gki8XKVYXyONQY2sRrGs5AFndCAgdNN-p-F1hMR8GW0tGqB5Z_aFaP4e9-ZDVZ49VQuviscFvu_ZjviSxjEgx-mEIpaRYViuZHhZ47GjUaxt6O0j_0XZwZ-LhE9d6S8bhnMV658kyR7AA",
            status="essential"
        ),
        PantryItem(
            id="ing-6",
            name="大号鸡蛋",
            category="meats",
            freshness=95,
            image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuBvRM-RZh3CUXjQRsbGcDbPrtQLmoXhIdCH4vnJR4QduBVdwYIqEhpWX2kn-p50gXjRaXjUG6Y0JXth8jOBINLX07YFhU4M-CpROjz_q-Vvlbq48Zb4EUBkTv3lRyONIUlpDIxIp6xixMzfx4IMc2y2BtXd5lBl_zdbsvuGZ24zFfAXvcy--kppw0_NjKtfyycGmHpfxpO74pNDo7pI3_lIyv8usp3tO2byzHvBTt69c7-IGhOX0dAYlfBY5KxhoxLT_pp0Wynq5A",
            status="essential"
        ),
        PantryItem(
            id="ing-7",
            name="酸种面包",
            category="staples",
            freshness=45,
            image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuCMFdYPsEzBK2KEhcyQxp0bbmgQaaHaj5JA95_PkxKaosYffbzCU2SqnNMj9FLEGSFKENJf3bDLQpS6ZC_V1d-A6uBLwdfB0Lz3GU6qkjoXMS4Y0IqewtKTbTmra4qLVJb1sNbn83EErk7yCyXcDIO67KlNiDoTPEAd79kXQ1q-ULyCHl_yRojXQSYKxMWyyNf1BZgZoUHb_rmJsbT5blm5BAWe6mEeIqWYeQ7Htl90MxO1P1QRJ6ODhWBPYJp8b0ExRcJCs6oPBQ",
            status="essential"
        ),
        PantryItem(
            id="ing-8",
            name="紫芦笋",
            category="vegetables",
            freshness=85,
            image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuDJOFqVrkOj9H8adTppLspjfGE9XR-CYaFpXrviB9-mgvJTbg-JKb8OffDMlWb-Sjo2nFRqmWVIk-Bhfaa3dKvugutCQjZKAzDeHgaT2lRg86AFf8Mwv6ApFKKhsvwofffomqNkWLksVBIkUxlI9gBCxSSU0ZTrGGymWXnZsZL5nGO_iBlQ5bYbpg-f037TVMRgWIkHLXzg7XrJs50HSblTm8kJSPyUIsnVurk4qMFfXN_dPOoK3cFC6Ydx4XTSpvevJvJvxLWXNg",
            status="seasonal",
            tag="春季首选"
        ),
        PantryItem(
            id="ing-9",
            name="新鲜大黄",
            category="vegetables",
            freshness=90,
            image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuDZ_digmZw_TajE5rCd7JoTEDTGwnCFDvf76UgSSes-p6vyxdzVoQUcGA04VUaydvdeVv0CkDDvGLhKJiXePelqhBKOEIK_IOrqYwclbORP3go08OPD17FIVvqib27yo4PzoqS3jDU0Vm9rS0wo2OhvS4qpc84RrNT30lTUnPiidHUCKIXCkySoZtNBhtV8HM2PAyVqJZ0kf2qx-WmX-eD9SWtK9MNDpoEu7jqYZs7JJlLFsp5gf93ymPwAFG8FFuyLrefhfbo3rw",
            status="seasonal",
            tag="新品到库"
        ),
    ]
    return await get_pantry()

@app.get("/api/profile", response_model=dict)
async def get_profile():
    return {
        "profile": user_profile,
        "history": user_history,
    }

@app.post("/api/profile/evolve", response_model=dict)
async def evolve_profile(request: dict):
    global user_profile, user_history
    
    recipe_title = request.get("recipe_title")
    ingredients = request.get("ingredients", [])
    
    user_profile["total_growth"] += 3
    if user_profile["total_growth"] >= 100:
        user_profile["total_growth"] = 50
        user_profile["level"] += 1
    
    user_profile["milestones"]["consistency_score"] = min(99, user_profile["milestones"]["consistency_score"] + 1)
    user_profile["milestones"]["new_flavors"] += 1
    
    user_history.insert(0, {
        "id": f"hist-{datetime.now().timestamp()}",
        "recipe_title": recipe_title or "自定义美食",
        "date": datetime.now().isoformat(),
        "action": "confirmed",
    })
    
    if ingredients and isinstance(ingredients, list):
        for ing in ingredients:
            name = ing if isinstance(ing, str) else ing.get("name")
            if not name:
                continue
            
            existing = next((m for m in user_profile["ingredients_mastered"] if m["name"] == name), None)
            if existing:
                existing["mastered"] = True
            else:
                user_profile["ingredients_mastered"].append({
                    "name": name,
                    "image_url": "https://lh3.googleusercontent.com/aida-public/AB6AXuAmzkt50Xj1yQCzNyd3p2eOtgQYhfKM_i9gV_611P8raJ40-B8-U1clhiRPjr4NmuESu5Uoq6d2-b3tz0kM-rPZ1dEG63ceRqFSh1CXw89unDJJjJJCZInZXkXP-HFDKgk10yYgeo4vMv7ofqKwr-e_vdE4zf5uWo6ykYTQ-Xwcc1nPVZAb9bwY9caW9vXK_HIGr5fMEGY1ZxJaeAbwiq8JbmMXZSiiOzf4zzGP3KRKi3XERrALOTSrFJ49csb77pyAdzqyDYybPA",
                    "mastered": True
                })
    
    user_profile["taste_dna"]["savory"] = min(100, user_profile["taste_dna"]["savory"] + (1 if random.random() > 0.5 else 0))
    user_profile["taste_dna"]["acidic"] = min(100, user_profile["taste_dna"]["acidic"] + (1 if random.random() > 0.6 else 0))
    user_profile["taste_dna"]["sweet"] = min(100, user_profile["taste_dna"]["sweet"] + (1 if random.random() > 0.8 else 0))
    
    return {
        "success": True,
        "profile": user_profile,
        "history": user_history,
    }

@app.post("/api/pantry/scan", response_model=dict)
async def scan_pantry(request: dict):
    image_base64 = request.get("image_base64")
    
    if image_base64:
        mock_scanned = ["有机鸡胸肉", "西红柿", "西兰花", "大蒜油"]
    else:
        mock_scanned = ["有机鸡胸肉", "西红柿", "西兰花", "大蒜油"]
    
    for name in mock_scanned:
        pantry_ingredients.insert(0, PantryItem(
            id=f"ing-{datetime.now().timestamp()}-{name}",
            name=name,
            category="meats",
            freshness=98,
            image_url="https://lh3.googleusercontent.com/aida-public/AB6AXuDFkb7bu2GNGivrinQd0gB2UWFq_fNEbdFUEeRkrnfWbGqMMmF2Jj51zZaV0js6kKkkv0XjKe7eGHrXAx9IgqTpBiR4WP8dlqomfzzc_gSS3tbIXmaKA0vk2-VNMUCO2Gki8XKVYXyONQY2sRrGs5AFndCAgdNN-p-F1hMR8GW0tGqB5Z_aFaP4e9-ZDVZ49VQuviscFvu_ZjviSxjEgx-mEIpaRYViuZHhZ47GjUaxt6O0j_0XZwZ-LhE9d6S8bhnMV658kyR7AA",
            status="essential"
        ))
    
    return {
        "success": True,
        "added": mock_scanned,
        "pantry": await get_pantry(),
    }

@app.post("/api/generate-recipe", response_model=dict)
async def generate_recipe(request: dict):
    preference = request.get("preference")
    selected_ingredients = request.get("selected_ingredients", [])
    previous_recipe_title = request.get("previous_recipe_title")
    evolve_prompt = request.get("evolve_prompt")
    
    ingredients_list = ", ".join(selected_ingredients) if selected_ingredients else "冰箱内现有食材"
    
    system_instruction = """You are BiteAI, an elite personalized culinary expert AI companion.
Generate a highly refined, healthy, gourmet recipe customized directly under user preferences, selected ingredients, and optional evolutionary requests.
You must output a single, complete JSON object conforming exactly to this schema:
{
  "title": "A highly creative Chinese recipe name e.g. 田园去皮叶菜能量碗",
  "matchPercent": 93,
  "tags": ["高蛋白质", "低升糖", "20分钟"],
  "calories": 420,
  "macros": { "protein": 18, "carb": 45, "fat": 22 },
  "description": "Brief welcoming intro explaining the culinary magic.",
  "whyRecommend": "Direct professional nutritional insight detailing how this recipe directly aids their specific feeling (e.g., fatigue, tiredness, gym recovery).",
  "ingredients": [
    { "name": "有机鹰嘴豆", "amount": "400g" }
  ],
  "steps": [
    {
      "step": 1,
      "title": "准备基底食材",
      "instruction": "详细处理及按摩菜叶操作步骤描述。"
    }
  ],
  "timing": "20分钟",
  "difficulty": "简单"
}"""
    
    user_prompt = f'User preference input: "{preference or "我想吃一些令人心情愉快的健康美食"}". Selected coordinates ingredients: [{ingredients_list}].'
    
    if previous_recipe_title and evolve_prompt:
        user_prompt += f' Evolve from the previous recipe "{previous_recipe_title}" with request: "{evolve_prompt}"'
    
    try:
        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": system_instruction},
                {"role": "user", "content": user_prompt}
            ],
            response_format={"type": "json_object"},
            temperature=0.7,
            max_tokens=4000
        )
        
        raw_text = response.choices[0].message.content
        parsed_recipe = json.loads(raw_text)
        
        images_mappers = get_aesthetic_recipe_images(parsed_recipe.get("title", ""), parsed_recipe.get("tags", []))
        parsed_recipe["id"] = f"rec-{datetime.now().timestamp()}"
        
        if parsed_recipe.get("steps") and isinstance(parsed_recipe["steps"], list):
            parsed_recipe["steps"] = [
                {
                    **step,
                    "image_url": images_mappers["step1_url"] if idx == 0 else (images_mappers["step2_url"] if idx == 1 else images_mappers["step3_url"])
                }
                for idx, step in enumerate(parsed_recipe["steps"])
            ]
        
        parsed_recipe["image_url"] = images_mappers["main_url"]
        
        return parsed_recipe
    
    except Exception as e:
        print(f"DeepSeek API error: {str(e)}")
        
        lower_pref = (preference or "").lower()
        selected_template = None
        
        if "累" in lower_pref or "冷" in lower_pref or "tired" in lower_pref:
            selected_template = default_recipes[1].copy()
            if evolve_prompt:
                selected_template["title"] = f"香辣进化 • {selected_template['title']}"
                selected_template["description"] = f"根据进化需求（{evolve_prompt}）进化：增加了辛姜原榨，提供更直接的心房温暖。"
                selected_template["tags"].insert(0, "香辣爆能")
        elif "健身" in lower_pref or "运动" in lower_pref or "体能" in lower_pref:
            selected_template = default_recipes[0].copy()
            if evolve_prompt:
                selected_template["title"] = f"增肌进化 • {selected_template['title']}"
                selected_template["description"] = f"根据进化需求（{evolve_prompt}）增加：提升了坚果脂肪比例及熟牛油果。"
                selected_template["tags"].insert(0, "超高能量")
        else:
            selected_template = default_recipes[random.randint(0, len(default_recipes)-1)].copy()
        
        selected_template["id"] = f"rec-{datetime.now().timestamp()}"
        return selected_template

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)